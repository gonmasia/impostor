// Base de datos de palabras por categoría
const wordDatabase = {
    comida: [
        'Pizza', 'Hamburguesa', 'Sushi', 'Tacos', 'Pasta', 'Helado', 'Chocolate',
        'Café', 'Pan', 'Queso', 'Arroz', 'Pollo', 'Ensalada', 'Sopa', 'Galletas',
        'Banana', 'Manzana', 'Naranja', 'Fresa', 'Agua', 'Jugo', 'Refresco'
    ],
    animales: [
        'Perro', 'Gato', 'León', 'Tigre', 'Elefante', 'Jirafa', 'Mono', 'Caballo',
        'Vaca', 'Cerdo', 'Oveja', 'Gallina', 'Pez', 'Tiburón', 'Ballena', 'Delfín',
        'Águila', 'Loro', 'Serpiente', 'Cocodrilo', 'Rana', 'Mariposa', 'Abeja'
    ],
    peliculas: [
        'Titanic', 'Avatar', 'Frozen', 'Toy Story', 'Matrix', 'Inception', 'Gladiador',
        'Avengers', 'Star Wars', 'Harry Potter', 'Jurassic Park', 'Batman', 'Spiderman',
        'Shrek', 'Coco', 'Up', 'Nemo', 'Cars', 'Ratatouille', 'Wall-E'
    ],
    deportes: [
        'Fútbol', 'Básquetbol', 'Tenis', 'Voleibol', 'Béisbol', 'Golf', 'Natación',
        'Ciclismo', 'Atletismo', 'Boxeo', 'Karate', 'Yoga', 'Surf', 'Esquí', 'Hockey',
        'Rugby', 'Ping Pong', 'Badminton', 'Escalada', 'Gimnasia'
    ],
    lugares: [
        'París', 'Nueva York', 'Tokio', 'Londres', 'Roma', 'Egipto', 'China', 'Brasil',
        'Australia', 'Playa', 'Montaña', 'Desierto', 'Selva', 'Ciudad', 'Pueblo',
        'Aeropuerto', 'Hospital', 'Escuela', 'Parque', 'Museo', 'Cine', 'Restaurante'
    ],
    profesiones: [
        'Doctor', 'Maestro', 'Policía', 'Bombero', 'Chef', 'Piloto', 'Ingeniero',
        'Arquitecto', 'Dentista', 'Enfermero', 'Músico', 'Actor', 'Deportista', 'Pintor',
        'Escritor', 'Programador', 'Abogado', 'Científico', 'Veterinario', 'Fotógrafo'
    ],
    objetos: [
        'Teléfono', 'Computadora', 'Reloj', 'Llave', 'Lápiz', 'Libro', 'Mesa', 'Silla',
        'Cama', 'Almohada', 'Espejo', 'Cepillo', 'Tijeras', 'Martillo', 'Linterna',
        'Paraguas', 'Mochila', 'Botella', 'Vaso', 'Plato', 'Cuchara', 'Tenedor'
    ],
    vehiculos: [
        'Auto', 'Moto', 'Bicicleta', 'Camión', 'Autobús', 'Tren', 'Avión', 'Barco',
        'Submarino', 'Helicóptero', 'Cohete', 'Ambulancia', 'Taxi', 'Patrulla',
        'Camioneta', 'Scooter', 'Lancha', 'Yate', 'Tractor', 'Excavadora'
    ],
    festividades: [
        'Navidad', 'Año Nuevo', 'Pascua', 'Halloween', 'Cumpleaños', 'San Valentín',
        'Día del Padre', 'Día de la Madre', 'Independencia', 'Graduación', 'Boda',
        'Carnaval', 'Acción de Gracias', 'Día de Muertos'
    ],
    musica: [
        'Guitarra', 'Piano', 'Batería', 'Violín', 'Trompeta', 'Flauta', 'Saxofón',
        'Rock', 'Pop', 'Jazz', 'Reggae', 'Hip Hop', 'Salsa', 'Bachata', 'Tango',
        'Concierto', 'Disco', 'Canción', 'Banda', 'Cantante'
    ],
    naturaleza: [
        'Árbol', 'Flor', 'Rosa', 'Sol', 'Luna', 'Estrella', 'Nube', 'Lluvia', 'Trueno',
        'Río', 'Lago', 'Mar', 'Océano', 'Montaña', 'Valle', 'Bosque', 'Pradera',
        'Volcán', 'Cascada', 'Arcoíris', 'Viento', 'Nieve'
    ],
    tecnologia: [
        'Internet', 'WiFi', 'Email', 'Redes Sociales', 'Instagram', 'Facebook', 'YouTube',
        'Netflix', 'Spotify', 'Google', 'App', 'Software', 'Hardware', 'Mouse', 'Teclado',
        'Monitor', 'USB', 'Bluetooth', 'Tablet', 'Smartwatch', 'Videojuego', 'PlayStation'
    ]
};

// Estado del juego
const game = {
    players: [],
    impostorIndex: null,
    secretWord: '',
    category: '',
    totalRounds: 3,
    currentRound: 0,
    currentPlayerIndex: 0,
    roundClues: [],
    allClues: [],
    votes: {},
    groupScore: 0,
    impostorScore: 0,
    usedWords: [],

    // Ir a pantalla de ingreso de nombres
    goToNameEntry() {
        const playerCount = parseInt(document.getElementById('playerCount').value);

        if (playerCount < 4 || playerCount > 10) {
            alert('El número de jugadores debe estar entre 4 y 10');
            return;
        }

        this.playerCount = playerCount;
        this.category = document.getElementById('category').value;

        // Generar inputs para nombres
        const nameInputsDiv = document.getElementById('nameInputs');
        nameInputsDiv.innerHTML = '';

        for (let i = 1; i <= playerCount; i++) {
            const inputGroup = document.createElement('div');
            inputGroup.className = 'name-input-group';
            inputGroup.innerHTML = `
                <label>Jugador ${i}:</label>
                <input type="text" id="playerName${i}" placeholder="Nombre del jugador ${i}" value="Jugador ${i}">
            `;
            nameInputsDiv.appendChild(inputGroup);
        }

        this.showScreen('screen-names');

        // Enfocar primer input
        setTimeout(() => {
            document.getElementById('playerName1').focus();
            document.getElementById('playerName1').select();
        }, 300);
    },

    // Volver al inicio
    backToStart() {
        this.showScreen('screen-start');
    },

    // Iniciar juego
    startGame() {
        // Recoger nombres de jugadores
        this.players = [];
        for (let i = 1; i <= this.playerCount; i++) {
            const nameInput = document.getElementById(`playerName${i}`);
            let name = nameInput.value.trim();

            if (!name) {
                name = `Jugador ${i}`;
            }

            this.players.push({
                id: i,
                name: name,
                isImpostor: false
            });
        }

        // Seleccionar impostor aleatorio
        this.impostorIndex = Math.floor(Math.random() * this.playerCount);
        this.players[this.impostorIndex].isImpostor = true;

        // Seleccionar palabra secreta
        this.selectSecretWord();

        this.currentRound = 0;
        this.currentPlayerIndex = 0;
        this.allClues = [];

        this.showScreen('screen-reveal');
        this.updateRevealScreen();
    },

    // Seleccionar palabra secreta
    selectSecretWord() {
        let category = this.category;

        if (category === 'aleatorio') {
            const categories = Object.keys(wordDatabase);
            category = categories[Math.floor(Math.random() * categories.length)];
        }

        const words = wordDatabase[category];
        let word;

        do {
            word = words[Math.floor(Math.random() * words.length)];
        } while (this.usedWords.includes(word));

        this.usedWords.push(word);
        this.secretWord = word;
    },

    // Actualizar pantalla de revelación
    updateRevealScreen() {
        const player = this.players[this.currentPlayerIndex];
        document.getElementById('currentPlayerName').textContent = player.name;
    },

    // Revelar palabra
    revealWord() {
        const player = this.players[this.currentPlayerIndex];
        const wordDisplay = document.getElementById('wordDisplay');

        if (player.isImpostor) {
            wordDisplay.innerHTML = `
                <div class="word-card impostor">
                    <h1>🎭 ERES EL IMPOSTOR</h1>
                    <p style="font-size: 1.2rem; margin-top: 20px;">
                        Escucha las pistas de los demás e intenta adivinar la palabra secreta.
                        Debes dar pistas convincentes sin saber cuál es la palabra.
                    </p>
                    <div class="impostor-tips">
                        <strong>Tips:</strong>
                        <ul>
                            <li>Da pistas vagas pero creíbles</li>
                            <li>Imita el estilo de otros jugadores</li>
                            <li>No seas demasiado específico</li>
                        </ul>
                    </div>
                </div>
            `;
        } else {
            wordDisplay.innerHTML = `
                <div class="word-card crewmate">
                    <h1>🔍 TU PALABRA ES:</h1>
                    <div class="secret-word">${this.secretWord}</div>
                    <p style="font-size: 1rem; margin-top: 20px; opacity: 0.9;">
                        Da pistas que ayuden a otros a identificar al impostor,<br>
                        pero no reveles la palabra directamente.
                    </p>
                    <div class="crewmate-tips">
                        <strong>Tips:</strong>
                        <ul>
                            <li>Sé específico pero no obvio</li>
                            <li>Evita sinónimos directos</li>
                            <li>Piensa en características únicas</li>
                        </ul>
                    </div>
                </div>
            `;
        }

        this.showScreen('screen-word');
    },

    // Siguiente jugador en revelación
    nextPlayer() {
        this.currentPlayerIndex++;

        if (this.currentPlayerIndex >= this.players.length) {
            // Todos vieron su palabra/rol, mostrar pantalla final
            this.showFinalScreen();
        } else {
            this.showScreen('screen-reveal');
            this.updateRevealScreen();
        }
    },

    // Mostrar pantalla final para jugar
    showFinalScreen() {
        const finalInfo = document.querySelector('.final-info');
        const impostor = this.players[this.impostorIndex];

        document.querySelector('.secret-word-reveal').textContent = this.secretWord;

        this.showScreen('screen-final');
    },


    // Jugar de nuevo
    playAgain() {
        // Reiniciar con los mismos jugadores pero nueva palabra y nuevo impostor
        this.impostorIndex = Math.floor(Math.random() * this.players.length);
        this.players.forEach((p, i) => {
            p.isImpostor = (i === this.impostorIndex);
        });

        this.selectSecretWord();
        this.currentPlayerIndex = 0;

        this.showScreen('screen-reveal');
        this.updateRevealScreen();
    },

    // Terminar juego y volver al inicio
    endGame() {
        // Reiniciar todo
        this.players = [];
        this.impostorIndex = null;
        this.secretWord = '';
        this.category = '';
        this.currentPlayerIndex = 0;
        this.usedWords = [];

        // Volver a la pantalla de inicio
        this.showScreen('screen-start');
    },

    // Mostrar pantalla
    showScreen(screenId) {
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        document.getElementById(screenId).classList.add('active');
    }
};

// Inicializar
window.addEventListener('load', () => {
    game.showScreen('screen-start');
});
